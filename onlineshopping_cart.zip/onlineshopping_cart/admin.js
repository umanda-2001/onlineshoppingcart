let products = JSON.parse(localStorage.getItem("products")) || [];

function addProduct() {
  const newProduct = {
    id: Date.now(),
    name: document.getElementById("name").value,
    price: document.getElementById("price").value,
    category: document.getElementById("category").value
  };

  products.push(newProduct);
  localStorage.setItem("products", JSON.stringify(products));

  alert("Product Added!");
}

function deleteProduct(id) {
  products = products.filter(p => p.id !== id);
  localStorage.setItem("products", JSON.stringify(products));
}