function toggleTheme() {
  document.body.classList.toggle("dark");
}
<button onclick="toggleTheme()">🌙 Toggle Theme</button>