function login(type) {
  const user = {
    type: type,
    time: new Date()
  };

  localStorage.setItem("user", JSON.stringify(user));

  showToast(type + " login successful");

  setTimeout(() => {
    window.location.href = "index.html";
  }, 1000);
}