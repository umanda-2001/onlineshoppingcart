import { products } from "./data.js";

let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Render products
export function renderProducts(filter = "All") {
  const container = document.getElementById("productContainer");
  container.innerHTML = "";

  products.forEach(p => {
    if (filter === "All" || p.category === filter) {

      const discountedPrice = p.price - (p.price * p.discount / 100);

      container.innerHTML += `
        <div class="product-card">
          <img src="${p.image}" width="100%">
          <h3>${p.name}</h3>
          <p>⭐ ${p.rating}</p>
          <p>
            <del>$${p.price}</del>
            <b>$${discountedPrice.toFixed(2)}</b>
          </p>

          <button onclick="addToCart(${p.id})">Add to Cart</button>
        </div>
      `;
    }
  });
}

// Add to cart
window.addToCart = (id) => {
  const item = products.find(p => p.id === id);
  cart.push(item);

  localStorage.setItem("cart", JSON.stringify(cart));

  showToast("Added to cart!");
};

// Toast notification
function showToast(msg) {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerText = msg;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 2000);
}

// Search
window.searchProduct = (value) => {
  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(value.toLowerCase())
  );

  const container = document.getElementById("productContainer");
  container.innerHTML = "";

  filtered.forEach(p => {
    container.innerHTML += `
      <div class="product-card">
        <h3>${p.name}</h3>
      </div>
    `;
  });
};
let user =
localStorage.getItem("user");

if(user){
    document.getElementById(
        "userStatus"
    ).innerHTML =
    "✅ Logged In";
}
else{
    document.getElementById(
        "userStatus"
    ).innerHTML =
    '<a href="login.html">Login</a>';
}