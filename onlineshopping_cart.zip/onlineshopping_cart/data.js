export const products = [
  {
    id: 1,
    name: "Red Apple",
    category: "Fruits",
    price: 2,
    image: "assets/images/apple.jpg",
    rating: 4.5,
    discount: 10
  },
  {
    id: 2,
    name: "Banana Bundle",
    category: "Fruits",
    price: 1.5,
    image: "assets/images/banana.jpg",
    rating: 4.2,
    discount: 5
  },
  {
    id: 3,
    name: "Fresh Carrot",
    category: "Vegetables",
    price: 3,
    image: "assets/images/carrot.jpg",
    rating: 4.0,
    discount: 0
  },
  {
    id: 4,
    name: "Chocolate Cake",
    category: "Cakes",
    price: 12,
    image: "assets/images/cake.jpg",
    rating: 5,
    discount: 15
  }
];