// ---------------- PRODUCTS ----------------
let products = [
  { id: 1, name: "Apple", category: "Fruits", price: 2 },
  { id: 2, name: "Banana", category: "Fruits", price: 1 },
  { id: 3, name: "Carrot", category: "Vegetables", price: 3 },
  { id: 4, name: "Chocolate Cake", category: "Cakes", price: 10 }
];

// Save initial data
if (!localStorage.getItem("products")) {
  localStorage.setItem("products", JSON.stringify(products));
}

// ---------------- LOAD PRODUCTS ----------------
function loadProducts() {
  let list = document.getElementById("productList");
  if (!list) return;

  let category = document.getElementById("category").value;
  let data = JSON.parse(localStorage.getItem("products"));

  list.innerHTML = "";

  data.forEach(p => {
    if (category === "All" || p.category === category) {
      list.innerHTML += `
        <div class="card">
          <h3>${p.name}</h3>
          <p>${p.category}</p>
          <p>$${p.price}</p>
          <button class="btn" onclick="addToCart(${p.id})">Add to Cart</button>
        </div>
      `;
    }
  });
}

// ---------------- CART ----------------
function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let product = JSON.parse(localStorage.getItem("products")).find(p => p.id === id);

  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));

  alert("Added to cart!");
}

// Display cart
function loadCart() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let container = document.getElementById("cartItems");
  if (!container) return;

  container.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;

    container.innerHTML += `
      <div class="card">
        <h3>${item.name}</h3>
        <p>$${item.price}</p>
        <button class="btn-danger" onclick="removeItem(${index})">Remove</button>
      </div>
    `;
  });

  document.getElementById("total").innerText = total;
}

function removeItem(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  loadCart();
}

// ---------------- LOGIN ----------------
function login(type) {
  localStorage.setItem("user", type);
  alert(type + " Login Successful!");
  window.location.href = "index.html";
}

// Auto load
if (window.location.pathname.includes("products")) loadProducts();
if (window.location.pathname.includes("cart")) loadCart();